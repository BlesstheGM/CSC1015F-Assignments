# program to determine whether a year is a leap year or not
# Blessing Hlongwane
# HLNBLE002
# 24 February 2023

year = int(input("Enter a year:\n"))
leap_year = year % 4 # Check if there is a remainder

if leap_year == 0:
    if year % 100 == 0:
        four_hundred = year % 400
        if four_hundred == 0:
            print(year, "is a leap year.")
        else:
            print(year, "is not a leap year.")
    else:
        print(year, "is a leap year.")
else:
    print(year, "is not a leap year.")