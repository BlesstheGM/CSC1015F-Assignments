# program that outputs ASC11 Art
# Blessing Hlongwane
# HLNBLEOO2
# 24 February 2023

print("(\\\               (\/)")
print("( '')    (\_/)   (.. )   //)")
print("O(\")(\") (\\'.'/) (\")(\")O (\" )")
print("        (\")_(\")        ()()o")