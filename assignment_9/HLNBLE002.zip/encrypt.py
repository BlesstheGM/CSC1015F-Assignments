# program to encrypt a message
# Blessing Hlongwane
# HLNBLE002
# 25 April 2023


index = 0
message = list(input("Enter a message:\n")) # Make the message a list
new_message = ""

def convert(message, index):
    global new_message
    if len(message) != index:
        if message[index] == 'z': # If character is z , replace with a
            new_message += 'a'
        elif message[index] == ' ': #If character is a space then replace with space
            new_message += ' '
        elif message[index] == '.':
            new_message += '.'
        else:
            new_message += chr(ord(message[index])+1)
        convert(message, index+1)
    return new_message

print("Encrypted message:")

if ''.join(message).islower():
    print(convert(message, index))
else:
    print(''.join(message))