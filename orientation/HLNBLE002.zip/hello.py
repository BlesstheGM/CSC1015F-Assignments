# My very first program to display Hello World on screen
# HLNBLE002
# Blessing Hlongwane
# 16 February 2023

print("Hello World")