# program to calculate energy
# Name: Blessing Hlongwane
# Student Number: HLNBLE002
# Date: 18 February 2023

m = eval(input("Enter the value of m: \n")) # variable to store m
c = eval(input("Enter the value of c: \n")) # variable to store c

energy = m * c ** 2 # calculation of energy

print("The value of energy, E, is:",energy)