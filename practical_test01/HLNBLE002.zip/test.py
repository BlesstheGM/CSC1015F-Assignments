# program to calculate output after inputing real numbers
# Blessing Hlongwane
# HLNBLE002
# 27 February 2023

i = eval(input("Enter the value of i:\n"))
j = eval(input("Enter the value of j:\n"))
k = eval(input("Enter the value of k:\n"))
 
answer = (k**5)*(i-j)*(10-j) # Calculates the answer
print("The answer is", answer, end=".") # Prints out the final answer